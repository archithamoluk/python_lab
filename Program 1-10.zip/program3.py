#program to find sum of two numbers
num1=10
num2=20
sum=num1+num2 #sum is calculated by adding num1 and num2
print(sum)