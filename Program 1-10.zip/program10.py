#Program to calculate the volume of a cylinder
h=float(input("enter the height of cylinder"))
r=float(input("enter the radius of cylinder"))
v=3.14*(r*r)*h
print("Volume of the cylinder is:",v)