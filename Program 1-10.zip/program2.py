#area of rectangle
l=10
b=20
area=l*b
print(area)

