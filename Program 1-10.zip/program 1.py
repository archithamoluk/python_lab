
b=30
a=30
print(a)
print(b)






