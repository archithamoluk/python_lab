#program to swap two variables
a=int(input("Enter the first number"))
b=int(input("Enter the second number"))
temp=a
a=b
b=temp
print("swaped number to a is:",a)
print("Swaped number to b is:",b)