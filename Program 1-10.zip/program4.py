#program to convert temperature into farenheit
celsius=float(input("Enter the temperature in degree celsius"))
farenheit=(celsius*(9/5))+32
print("Temperature in farenheit:",farenheit)