#program to calculate radius of a circle
a=float(input("Enter the radius of a circle"))
r=3.14*a*a
print("Radius of circle entered:",r)
