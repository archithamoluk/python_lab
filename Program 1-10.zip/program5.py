#program to convert kilometers into miles
kilometers=float(input("Enter the distance in kilometers"))
miles=(kilometers/1.609)
print("The converted distance in miles is:",miles)