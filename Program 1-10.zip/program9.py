#program to convert feet into inches
feet=float(input("Enter your hieght in feet"))
inches=(feet*12)
print("your height in inches is:",inches)