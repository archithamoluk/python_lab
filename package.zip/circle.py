def circle(r):
    print("AREA IS :",+3.14*(r*r))
    print("PERIMETER :", +2*(3.14 * r ))