def sphere(r):
    print("AREA IS:",4*3.14*r*r)
    print("VOLUME IS:", 4/3*3.14*r*r*r)