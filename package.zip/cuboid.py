def cuboid(l,b,h):
      print("AREA IS:",2*l*b+b*h+h*l)
      print("PERIMETER IS:",4*(l+b+h))

