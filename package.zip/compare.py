class rectangle:
    def __init__(self, l1, b1):
        self.l = l1
        self.b = b1

    def area(self):
       return(self.l*self.b)

    def peri(self):
        print("PERIMETER :", (2 * (self.l + self.b)))
    def compare(self, obj):
        if (self.area() == obj.area()):
            print("RECTANGLES ARE EQUAL")
        else:
            print("RECTANGLES ARE NOT EQUAL")


r1 = rectangle(5, 2)
a=r1.area()
print ("AREA:",a)
r1.peri()
r2 = rectangle(6,8 )
b=r2.area()
print ("AREA:",b)
r2.peri()
r1.compare(r2)
