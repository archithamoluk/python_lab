def rect(l,b):
    print("Area of rectangle:",+l*b)
    print("PERIMETER of rectangle:", +2*(l + b))