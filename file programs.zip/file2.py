import csv
with open("desp.csv",newline='') as csvfile:
    d=csv.DictReader(csvfile)
    print("period   subject")
    print("----------------")
    for i in d:
        print(i['Period'],i['Subject'])

