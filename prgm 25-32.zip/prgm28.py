str1 = input("enter the first string:")
str2 = input("enter the second string:")
a = str2[:1]
b = str1[1:]
c = str1[:1]
d = str2[1:]
print("after swapping:", a+b+" "+c+d)