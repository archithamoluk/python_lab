
list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
n = [list1.remove(a) for a in list1 if a%2==0]
print(list1)