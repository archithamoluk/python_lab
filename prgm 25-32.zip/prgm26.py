color = input("enter colors:")
color_list = color.split(",")
print("first color:", color_list[0])
print("last color:", color_list[-1])
