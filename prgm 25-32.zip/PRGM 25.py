str1 = input("Enter a string:")
a = str1[-1]
b = str1[1:-1]
c = str1[0]
print(a+b+c)


