dict1 = {"Name": "Avani", "Dep": "MCA"}
dict2 = {"College": "AJCE"}
print("Dictionary 1:", dict1)
print("Dictionary 2:", dict2)
a = dict1.copy()
a.update(dict2)
print("Merged Dictionary:",a)
