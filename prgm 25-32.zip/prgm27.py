list1 = {"white", "pink", "yellow", "black"}
list2 = {"pink", "red", "blue", "grey"}
new_list = list1.difference(list2)
print(new_list)