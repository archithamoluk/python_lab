list1 = [10, 20, 30, 40, 50]
a = 0
for i in list1:
    a = a+i
print(a)