age=int(input("ENTER YOUR AGE:"))
if(age>=18):
    print("ELIGIBLE TO VOTE")
else:
    print("NOT ELIGIBLE")