colour=(input("ENTER THE COLOUR OF SIGNAL:"))
if(colour=="red" or colour=="RED"):
    print("STOP")
elif(colour=="green" or colour=="GREEN"):
    print("GO")
elif(colour=="yellow" or colour=="YELLOW"):
    print("GO SLOW")
else:
    print("INVALID!!!!")
