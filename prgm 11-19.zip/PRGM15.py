a=int(input("ENTER FIRST NUMBER:"))
b=int(input("ENTER SECOND NUMBER:"))
opt=int(input("1.ADDITION \n 2.SUBTRACTION \n 3.MULTIPLICATION \n 4.DIVISION \n"))
if(opt==1):
    c= a+b
    print("SUM=", +c)
elif(opt==2):
    c=a-b
    print("DIFFERENCE=", +c)
elif(opt==3):
    c=a*b
    print("PRODUCT=", +c)
elif(opt==4):
     c=a/b
     print("DIVISION=", +c)
else:
     print("invalid")