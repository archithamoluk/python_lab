# Program to create dictionary and print it
dict1 = {'car':'swift','two wheeler':'dio'}
print(dict1)