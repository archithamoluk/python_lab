for a in 'PYTHON':
    print(a)