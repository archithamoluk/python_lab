tuple1=(10,20,"Apple","23C")
print(tuple1)