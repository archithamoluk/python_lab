currentyear=int(input("Enter current year:"))
finalyear=int(input("Enter  final year:"))
print("list of leap year")
for year in range(currentyear,finalyear):
    if(0==year%4) and (0!=year%100) or (0==year%400):
        print(year)